﻿using Microsoft.Web.WebView2.Wpf;
using System.ComponentModel;

namespace CorexBrowser.Models
{
    public class BrowserTab : INotifyPropertyChanged
    {
        public WebView2 WebView { get; set; }

        private string _title = "Yeni Sekme";
        public string Title
        {
            get => _title;
            set
            {
                _title = value;
                PropertyChanged?.Invoke(this,
                    new PropertyChangedEventArgs(nameof(Title)));
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
