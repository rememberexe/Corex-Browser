﻿using CorexBrowser.Helpers;
using Microsoft.Web.WebView2.Core;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using CorexBrowser.Models;
using System.Collections.ObjectModel;

using System.Windows.Shapes;
using Microsoft.Web.WebView2.Wpf;

namespace Corex_Browser
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<BrowserTab> Tabs { get; } = new();
        private BrowserTab? ActiveTab;

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            SourceInitialized += (_, _) =>
            {
                WindowThemeHelper.EnableDarkTitleBar(this);
            };
          
        }
        private async void CreateNewTab(string? url = null)
        {
            var webView = new WebView2();

            var userDataPath = System.IO.Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "CorexBrowser");

            var env = await CoreWebView2Environment.CreateAsync(null, userDataPath);
            await webView.EnsureCoreWebView2Async(env);

            var tab = new BrowserTab
            {
                WebView = webView
            };

            webView.CoreWebView2.DocumentTitleChanged += (_, _) =>
            {
                tab.Title = webView.CoreWebView2.DocumentTitle;
            };

            webView.CoreWebView2.Navigate(url ?? "https://www.google.com");

            Tabs.Add(tab);
            SwitchTab(tab);
        }
        private void SwitchTab(BrowserTab tab)
        {
            if (ActiveTab != null)
                ActiveTab.WebView.Visibility = Visibility.Collapsed;

            ActiveTab = tab;

            if (!BrowserHost.Children.Contains(tab.WebView))
                BrowserHost.Children.Add(tab.WebView);

            tab.WebView.Visibility = Visibility.Visible;

            AddressBar.Text = tab.WebView.Source?.ToString();
        }

        private void Window_SourceInitialized(object? sender, EventArgs e)
        {
            WindowThemeHelper.EnableDarkTitleBar(this);
            InitializeBrowser();
            CreateNewTab();
        }

        private void OnSourceInitialized(object? sender, EventArgs e)
        {
            WindowThemeHelper.EnableDarkTitleBar(this);
            InitializeBrowser();
        }

        private async void InitializeBrowser()
        {
            if (Browser == null)
                return;

            var userDataPath = System.IO.Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "CorexBrowser");

            var env = await CoreWebView2Environment.CreateAsync(
                null,
                userDataPath);

            await Browser.EnsureCoreWebView2Async(env);

            Browser.CoreWebView2.Navigate("https://www.google.com");
        }



        private void AddressBar_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && Browser.CoreWebView2 != null)
            {
                var url = AddressBar.Text.Trim();

                if (!url.StartsWith("http"))
                    url = "https://" + url;

                Browser.CoreWebView2.Navigate(url);
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            if (Browser.CoreWebView2?.CanGoBack == true)
                Browser.CoreWebView2.GoBack();
        }

        private void Forward_Click(object sender, RoutedEventArgs e)
        {
            if (Browser.CoreWebView2?.CanGoForward == true)
                Browser.CoreWebView2.GoForward();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            Browser.CoreWebView2?.Reload();
        }

    }
}