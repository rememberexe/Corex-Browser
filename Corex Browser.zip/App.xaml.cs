﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Corex_Browser
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
